# Astrobot

Tutorial install di termux



apt update& upgrade




pkg install git



pkg install python2 



ketik "git clone https://github.com/cismin333/Astrobot"




pip2 install request



pip2 install thrift==0.9.3



pip2 install rsa



cd Astrobot




python2 Astrobot.py




Terimakasih buat TCT buat TCR, dan buat mastah programmer lainnya
